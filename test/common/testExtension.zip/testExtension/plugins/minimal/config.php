<?php

# Here you can include any libs, plugins, files, etc.
# e.g.: require_once dirname(__FILE__) . '/...';

echo '[ Plugin config loaded ]';

?>