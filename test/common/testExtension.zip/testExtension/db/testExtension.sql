INSERT INTO `test`.`models` (
`modelID` ,
`modelURI` ,
`baseURI`
)
VALUES (
'22', 'test', 'test'
);
