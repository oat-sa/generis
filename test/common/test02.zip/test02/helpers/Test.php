<?php
function test_helpers()
{
	echo 'Helper loaded and used successfuly !';
}
?>