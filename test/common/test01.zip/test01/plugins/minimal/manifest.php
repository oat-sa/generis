<?php
	return array(
		'name' => 'Beautiful Plugin Name',
		'description' => 'plugin Description',
		'additional' => array(
			'specificParameters1' => 'any values, string, array, ...',
			'specificParameters2' => 'any values, string, array, ...',
		)
	);
?>