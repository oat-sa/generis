<?php

class ModelMinimalPlugin {

	static public function getStatus(){
		return 'ok';
	}
}

?>