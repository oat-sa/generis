<?php
	return array(
		'name' => 'Test01',
		'description' => 'Test Extension',
		'additional' => array(
			'version' => '0.1',
			'author' => 'CRP Henry Tudor',
			'dependances' => array('UserFrontend' , 'WorkflowEngine'),
			'registerToClassLoader' => true,
			'configFile' => dirname(__FILE__). '/includes/common.php',
			'classLoaderPackages' => array( 
				dirname(__FILE__).'/actions/' , 
				dirname(__FILE__).'/models/',
				
			)
		)
	);
?>