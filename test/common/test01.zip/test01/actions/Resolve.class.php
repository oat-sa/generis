<?php
class Resolve extends Module
{
	public function index()
	{
		echo 'Default action from Resolve module executed';
	}
	
	public function action()
	{
		echo 'Action action from Resolve module executed';
	}
}
?>