<?php

/**
 * default action
 * must be in the actions folder
 */
class AdvancedDefault extends Module {

	/**
	 * Index page
	 */
    public function index() {
		echo 'index';
    }

}
?>