<?php
class Users extends Module {

    public function index() {
		echo 'Users/index';
    }
    
    public function auth() {
    	echo 'Users/auth';
    }

}
?>